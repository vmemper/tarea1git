package prueba;

import java.util.Scanner;

public class SumaGit {

	public static void main(String[] args) {
		Scanner valores = new Scanner(System.in);
		System.out.println("SUMA");
		System.out.println("Primer valor");
		int valor1 = Integer.parseInt(valores.nextLine()); 
		System.out.println("Segundo valor");
		int valor2 = Integer.parseInt(valores.nextLine()); 
		int resultadoSuma = valor1 + valor2;
		System.out.println("El resultado de la suma es: " +resultadoSuma);
		
		valores.close();
	}

}

