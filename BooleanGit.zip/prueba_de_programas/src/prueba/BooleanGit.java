package prueba;

import java.util.Scanner;

public class BooleanGit {

	public static void main(String[] args) {
		Scanner valor = new Scanner(System.in);
		System.out.println("Introduzca un número: ");
		double numero = Integer.parseInt(valor.nextLine());
		
		valor.close();
		
		double resultado = numero % 2;
		boolean par = resultado == 0;
		
		if(par==true){
			System.out.println("Su número es: par");
		}else {
			System.out.println("Su número es: impar");
		}		
	}
}

